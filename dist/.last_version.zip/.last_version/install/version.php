<?
$arModuleVersion = array(
    "VERSION" => "2.1.7",
    "VERSION_DATE" => "2025-09-01 11:17:00"
);