<?
$arModuleVersion = array(
    "VERSION" => "2.0.3",
    "VERSION_DATE" => "2025-06-08 17:09:00"
);