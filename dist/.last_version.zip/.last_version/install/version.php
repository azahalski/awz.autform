<?
$arModuleVersion = array(
    "VERSION" => "2.1.5",
    "VERSION_DATE" => "2025-07-27 10:05:00"
);