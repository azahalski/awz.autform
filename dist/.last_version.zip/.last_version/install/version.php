<?
$arModuleVersion = array(
    "VERSION" => "2.0.7",
    "VERSION_DATE" => "2025-06-08 23:03:00"
);