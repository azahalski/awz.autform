<?
$arModuleVersion = array(
    "VERSION" => "2.1.4",
    "VERSION_DATE" => "2025-07-20 15:26:00"
);