<?
$arModuleVersion = array(
    "VERSION" => "2.1.6",
    "VERSION_DATE" => "2025-08-26 11:17:00"
);