<?
$arModuleVersion = array(
    "VERSION" => "2.0.1",
    "VERSION_DATE" => "2025-06-08 03:37:00"
);