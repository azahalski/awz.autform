<?
$arModuleVersion = array(
    "VERSION" => "2.1.0",
    "VERSION_DATE" => "2025-06-13 23:51:00"
);