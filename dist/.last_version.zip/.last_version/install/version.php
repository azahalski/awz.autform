<?
$arModuleVersion = array(
    "VERSION" => "2.1.2",
    "VERSION_DATE" => "2025-06-21 11:53:00"
);