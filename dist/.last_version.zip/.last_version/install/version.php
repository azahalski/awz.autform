<?
$arModuleVersion = array(
    "VERSION" => "2.0.6",
    "VERSION_DATE" => "2025-06-08 22:45:00"
);