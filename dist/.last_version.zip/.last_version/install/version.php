<?
$arModuleVersion = array(
    "VERSION" => "2.1.1",
    "VERSION_DATE" => "2025-06-17 22:49:00"
);