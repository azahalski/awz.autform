<?
$arModuleVersion = array(
    "VERSION" => "2.1.3",
    "VERSION_DATE" => "2025-07-18 06:00:00"
);