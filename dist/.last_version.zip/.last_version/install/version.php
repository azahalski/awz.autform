<?
$arModuleVersion = array(
    "VERSION" => "2.0.4",
    "VERSION_DATE" => "2025-06-08 17:17:00"
);