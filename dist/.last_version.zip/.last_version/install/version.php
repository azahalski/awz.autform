<?
$arModuleVersion = array(
    "VERSION" => "2.0.9",
    "VERSION_DATE" => "2025-06-10 22:58:00"
);