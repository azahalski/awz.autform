<?
$arModuleVersion = array(
    "VERSION" => "2.0.5",
    "VERSION_DATE" => "2025-06-08 19:08:00"
);