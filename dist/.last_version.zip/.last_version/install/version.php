<?
$arModuleVersion = array(
    "VERSION" => "2.0.2",
    "VERSION_DATE" => "2025-06-08 16:38:00"
);