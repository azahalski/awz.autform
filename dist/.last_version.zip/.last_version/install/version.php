<?
$arModuleVersion = array(
    "VERSION" => "2.0.8",
    "VERSION_DATE" => "2025-06-10 16:01:00"
);