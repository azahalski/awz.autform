<?
$arModuleVersion = array(
    "VERSION" => "2.1.8",
    "VERSION_DATE" => "2025-09-25 11:42:00"
);