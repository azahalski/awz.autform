drop table if exists b_awz_autform_codes;
drop table if exists b_awz_autform_logs;